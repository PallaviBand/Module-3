package test;

import org.testng.annotations.Test;

public class ReturnValueSampleTest {

  @Test
  public int shouldRun() {
    return 0;
  }
}
