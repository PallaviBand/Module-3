[![Build Status](http://img.shields.io/travis/cbeust/testng.svg)](https://travis-ci.org/cbeust/testng)
[![Java9 EA Build Status](https://img.shields.io/jenkins/s/https/adopt-openjdk.ci.cloudbees.com/TestNG.svg?label="Java9 EA")](https://adopt-openjdk.ci.cloudbees.com/job/TestNG)
[![Java9 Jigsaw EA Build Status](https://img.shields.io/jenkins/s/https/adopt-openjdk.ci.cloudbees.com/TestNG-Jigsaw.svg?label="Java9 Jigsaw")](https://adopt-openjdk.ci.cloudbees.com/job/TestNG-Jigsaw)
[![AppVeyor](https://ci.appveyor.com/api/projects/status/github/cbeust/testng?svg=true)](https://ci.appveyor.com/project/cbeust/testng)
[![Dependency Status](https://www.versioneye.com/user/projects/553a031c4e5d2e9408000059/badge.svg)](https://www.versioneye.com/user/projects/553a031c4e5d2e9408000059)
[![Reference Status](https://www.versioneye.com/java/org.testng:testng/reference_badge.svg)](https://www.versioneye.com/java/org.testng:testng/references)
[![Maven Central](https://img.shields.io/maven-central/v/org.testng/testng.svg)](https://maven-badges.herokuapp.com/maven-central/org.testng/testng)
[![License](https://img.shields.io/github/license/cbeust/testng.svg)](https://www.apache.org/licenses/LICENSE-2.0.html)
[![Sonarqube tech debt](https://img.shields.io/sonar/http/nemo.sonarqube.org/org.testng:testng/tech_debt.svg?label=Sonarqube%20tech%20debt)](http://nemo.sonarqube.org/dashboard/index?id=org.testng:testng)

Documentation available at [TestNG's main web site](http://testng.org).
